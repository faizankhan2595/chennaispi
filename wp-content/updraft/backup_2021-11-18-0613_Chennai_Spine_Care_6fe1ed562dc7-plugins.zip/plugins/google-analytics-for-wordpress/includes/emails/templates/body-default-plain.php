<?php
echo "{email}";
