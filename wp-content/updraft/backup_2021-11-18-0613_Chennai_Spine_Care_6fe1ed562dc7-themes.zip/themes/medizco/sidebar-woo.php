
<aside id="sidebar" class="sidebar sidebar-left sidebar-woo col-md-4">
	<?php dynamic_sidebar( 'sidebar-woo' ); ?>
</aside> <!-- end sidebar -->

