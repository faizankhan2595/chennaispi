<?php

require __DIR__ . '/PHPInsight/Autoloader.php';
PHPInsight_Autoloader::register();
