<?php

define( 'REDIRECTION_VERSION', '5.1.3' );
define( 'REDIRECTION_BUILD', '81f455fc2a8faec560fb955b29f9a717' );
define( 'REDIRECTION_MIN_WP', '4.6' );
