/*
Theme Name: Medizco
Theme URI: https://themeforest.net/user/xpeedstudio/portfolio
Author: Xpeedstudio
Author URI: https://xpeedstudio.com/
Description: Medizco is a Medical Health Dental Care Clinic WordPress Theme.
Version: 2.4
License: GNU General Public License v2 or later
License URI: LICENSE
Text Domain: medizco
Tags: theme-options, post-formats, featured-images
*/

The latest updates to the Medizco theme

2.4  (01-27-2021)
Elementor new version compatibility

2.3 - 2021-1-4
Fixed:
    -- Doctor box waring issue
    -- Responsive issue fixed
    -- CSS issue fixed
Update:
    -- Demo content remote server change
    -- Add latest version rev slider (6.3.5)

2.1 - 2020-11-24
Doctor slider: Add option to ordring Doctors
Doctor slider: fix slider issue

2.2
2020-11-30
Fixed:
    -- Header sticky issue
Feature
    -- Banner breadcumb overlay background color and breadcumb text color change option

2020-12-02
Fixed:
    -- Ekit new version compatibility