<?php if (!defined('ABSPATH')) die('Direct access forbidden.');

$options = array(
    'medizco_product_cat'=>array(
        'type'  => 'new-icon',
        'label' =>esc_html__('Category icon', 'medizco'),
        'desc'  =>esc_html__('Category icon', 'medizco'),
    ),
);