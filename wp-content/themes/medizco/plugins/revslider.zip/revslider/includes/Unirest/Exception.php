<?php

namespace Unirest;

class Exception extends \Exception {}
