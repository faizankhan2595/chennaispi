<?php if (!defined('ABSPATH')) die('Direct access forbidden.');
/**
 * initial configs for unyson
 */


$cfg['settings_form_side_tabs'] = true;


